package com.example.maxercisewearos.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.maxercisewearos.data.repository.WorkoutRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val repository: WorkoutRepository) : ViewModel() {

    val activeRoutine = repository.activeRoutine.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val favoriteRoutines = repository.favoriteRoutines.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun sync(userId: Int) {
        viewModelScope.launch {
            repository.syncData(userId)
        }
    }
}
