package com.example.maxercisewearos.data.remote

import com.example.maxercisewearos.data.model.*
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.Path
import retrofit2.http.Body

interface ApiService {
    @GET("user/{userId}/active-routine")
    suspend fun getActiveRoutine(@Path("userId") userId: Int): UserActiveRoutine

    @GET("routine/{routineId}/exercises")
    suspend fun getRoutineExercises(@Path("routineId") routineId: Int): List<RoutineExercise>

    @GET("user/{userId}/favorite-routines")
    suspend fun getFavoriteRoutines(@Path("userId") userId: Int): List<UserFavoriteRoutine>

    @GET("user/{userId}/restrictions")
    suspend fun getUserRestrictions(@Path("userId") userId: Int): List<UserRestriction>

    @GET("exercise/{exerciseId}/restrictions")
    suspend fun getExerciseRestrictions(@Path("exerciseId") exerciseId: Int): List<ExerciseRestrictions>

    @PATCH("user/{userId}/active-routine")
    suspend fun updateActiveRoutineProgress(
        @Path("userId") userId: Int,
        @Body progress: Map<String, Int>
    )
}
