package com.example.maxercisewearos.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation3.runtime.NavEntry
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.ui.NavDisplay
import androidx.wear.compose.material3.AppScaffold
import androidx.wear.compose.navigation3.rememberSwipeDismissableSceneStrategy
import com.example.maxercisewearos.data.repository.WorkoutRepository
import com.example.maxercisewearos.presentation.screen.ExerciseScreen
import com.example.maxercisewearos.presentation.screen.HomeScreen
import com.example.maxercisewearos.presentation.screen.TimerScreen
import com.example.maxercisewearos.presentation.theme.MaxerciseWearOSTheme
import com.example.maxercisewearos.presentation.viewmodel.HomeViewModel
import com.example.maxercisewearos.presentation.viewmodel.TimerViewModel
import com.example.maxercisewearos.presentation.viewmodel.WorkoutViewModel
import kotlinx.serialization.Serializable

@Serializable object HomeDestination : NavKey
@Serializable object ExerciseDestination : NavKey
@Serializable object TimerDestination : NavKey

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Placeholder Base URL
        val baseUrl = "https://api.maxercise.com/"
        val repository = WorkoutRepository.create(baseUrl)

        setContent {
            WearApp(repository)
        }
    }
}

@Composable
fun WearApp(repository: WorkoutRepository) {
    MaxerciseWearOSTheme {
        AppScaffold {
            val backStack = rememberNavBackStack(HomeDestination)
            
            val homeViewModel: HomeViewModel = viewModel { HomeViewModel(repository) }
            val workoutViewModel: WorkoutViewModel = viewModel { WorkoutViewModel(repository) }
            val timerViewModel: TimerViewModel = viewModel()

            NavDisplay(
                backStack = backStack,
                entryProvider = { key ->
                    when (key) {
                        is HomeDestination -> NavEntry(key) {
                            HomeScreen(
                                viewModel = homeViewModel,
                                onStartWorkout = { backStack.add(ExerciseDestination) }
                            )
                        }
                        is ExerciseDestination -> NavEntry(key) {
                            ExerciseScreen(
                                viewModel = workoutViewModel,
                                onStartRest = { 
                                    timerViewModel.startTimer(60)
                                    backStack.add(TimerDestination) 
                                },
                                onFinishWorkout = {
                                    workoutViewModel.finishWorkout(1)
                                    backStack.removeAt(backStack.size - 1)
                                }
                            )
                        }
                        is TimerDestination -> NavEntry(key) {
                            TimerScreen(
                                viewModel = timerViewModel,
                                onFinish = { backStack.removeAt(backStack.size - 1) }
                            )
                        }
                        else -> NavEntry(key) { }
                    }
                },
                sceneStrategies = listOf(rememberSwipeDismissableSceneStrategy())
            )
        }
    }
}
