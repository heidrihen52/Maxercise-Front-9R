package com.example.maxercisewearos.presentation.screen

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.wear.compose.foundation.lazy.TransformingLazyColumn
import androidx.wear.compose.foundation.lazy.rememberTransformingLazyColumnState
import androidx.wear.compose.material3.*
import androidx.wear.compose.material3.lazy.rememberTransformationSpec
import androidx.wear.compose.material3.lazy.transformedHeight
import com.example.maxercisewearos.presentation.viewmodel.HomeViewModel

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onStartWorkout: () -> Unit,
    userId: Int = 1
) {
    val activeRoutine by viewModel.activeRoutine.collectAsStateWithLifecycle()
    val favorites by viewModel.favoriteRoutines.collectAsStateWithLifecycle()
    
    val listState = rememberTransformingLazyColumnState()
    val transformationSpec = rememberTransformationSpec()

    LaunchedEffect(Unit) {
        viewModel.sync(userId)
    }

    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            contentPadding = contentPadding
        ) {
            item {
                ListHeader(
                    modifier = Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                    transformation = SurfaceTransformation(transformationSpec)
                ) {
                    Text("Maxercise", textAlign = TextAlign.Center)
                }
            }

            item {
                TitleCard(
                    onClick = onStartWorkout,
                    modifier = Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                    title = { Text("🏋️ Mi Rutina Activa") },
                    subtitle = { 
                        Text(activeRoutine?.routine?.name ?: "Cargando...")
                    }
                )
            }

            item {
                ListHeader(
                    modifier = Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                    transformation = SurfaceTransformation(transformationSpec)
                ) {
                    Text("⭐ Favoritas", textAlign = TextAlign.Center)
                }
            }

            items(favorites.take(5).size) { index ->
                val routine = favorites[index]
                Button(
                    onClick = { /* Select as active then start */ },
                    modifier = Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                    transformation = SurfaceTransformation(transformationSpec)
                ) {
                    Text(routine.routine?.name ?: "Rutina ${routine.routine_id}")
                }
            }
        }
    }
}
