package com.example.maxercisewearos.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Exercise(
    val id: Int,
    val name: String,
    val description: String? = null
)

@Serializable
data class Restriction(
    val id: Int,
    val name: String
)

@Serializable
data class ExerciseRestrictions(
    val id: Int,
    val exercise_id: Int,
    val restriction_id: Int
)

@Serializable
data class Routine(
    val id: Int,
    val name: String
)

@Serializable
data class RoutineExercise(
    val id: Int,
    val reps: Int,
    val sets: Int,
    val day_number: Int,
    val order: Int,
    val routine_id: Int,
    val exercise_id: Int,
    val exercise: Exercise? = null
)

@Serializable
data class UserActiveRoutine(
    val id: Int,
    val user_id: Int,
    val routine_id: Int,
    val last_completed_day: Int,
    val routine: Routine? = null
)

@Serializable
data class UserFavoriteRoutine(
    val id: Int,
    val user_id: Int,
    val routine_id: Int,
    val routine: Routine? = null
)

@Serializable
data class UserRestriction(
    val id: Int,
    val user_id: Int,
    val restriction_id: Int,
    val restriction: Restriction? = null
)
