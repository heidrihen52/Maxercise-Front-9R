package com.example.maxercisewearos.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.maxercisewearos.data.model.RoutineExercise
import com.example.maxercisewearos.data.repository.WorkoutRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class WorkoutViewModel(private val repository: WorkoutRepository) : ViewModel() {

    val currentExercise = repository.routineExercises.combine(repository.currentExerciseIndex) { list, index ->
        list.getOrNull(index)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentSeries = repository.currentSeries.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1)

    private val _isSafe = MutableStateFlow(true)
    val isSafe: StateFlow<Boolean> = _isSafe

    private val _vibrationEvent = MutableSharedFlow<Unit>()
    val vibrationEvent = _vibrationEvent.asSharedFlow()

    init {
        viewModelScope.launch {
            currentExercise.collect { exercise ->
                exercise?.let {
                    val safe = repository.isExerciseSafe(it.exercise_id)
                    _isSafe.value = safe
                    if (!safe) {
                        _vibrationEvent.emit(Unit)
                    }
                }
            }
        }
    }

    fun completeSeries() {
        repository.nextSeries()
    }

    fun finishWorkout(userId: Int) {
        viewModelScope.launch {
            repository.finishBlock(userId)
        }
    }
}
