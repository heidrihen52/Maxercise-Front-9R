package com.example.maxercisewearos.data.repository

import com.example.maxercisewearos.data.model.*
import com.example.maxercisewearos.data.remote.ApiService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory

class WorkoutRepository(private val apiService: ApiService) {

    private val _activeRoutine = MutableStateFlow<UserActiveRoutine?>(null)
    val activeRoutine: StateFlow<UserActiveRoutine?> = _activeRoutine

    private val _routineExercises = MutableStateFlow<List<RoutineExercise>>(emptyList())
    val routineExercises: StateFlow<List<RoutineExercise>> = _routineExercises

    private val _favoriteRoutines = MutableStateFlow<List<UserFavoriteRoutine>>(emptyList())
    val favoriteRoutines: StateFlow<List<UserFavoriteRoutine>> = _favoriteRoutines

    private val _userRestrictions = MutableStateFlow<List<UserRestriction>>(emptyList())
    val userRestrictions: StateFlow<List<UserRestriction>> = _userRestrictions

    // In-memory progress
    private val _currentExerciseIndex = MutableStateFlow(0)
    val currentExerciseIndex: StateFlow<Int> = _currentExerciseIndex

    private val _currentSeries = MutableStateFlow(1)
    val currentSeries: StateFlow<Int> = _currentSeries

    suspend fun syncData(userId: Int) {
        try {
            val active = apiService.getActiveRoutine(userId)
            _activeRoutine.value = active
            
            val exercises = apiService.getRoutineExercises(active.routine_id)
            _routineExercises.value = exercises.sortedBy { it.order }

            val favorites = apiService.getFavoriteRoutines(userId)
            _favoriteRoutines.value = favorites

            val restrictions = apiService.getUserRestrictions(userId)
            _userRestrictions.value = restrictions
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun nextSeries() {
        val currentEx = _routineExercises.value.getOrNull(_currentExerciseIndex.value) ?: return
        if (_currentSeries.value < currentEx.sets) {
            _currentSeries.value += 1
        } else {
            if (_currentExerciseIndex.value < _routineExercises.value.size - 1) {
                _currentExerciseIndex.value += 1
                _currentSeries.value = 1
            }
        }
    }

    suspend fun finishBlock(userId: Int) {
        val active = _activeRoutine.value ?: return
        try {
            apiService.updateActiveRoutineProgress(
                userId, 
                mapOf("last_completed_day" to active.last_completed_day + 1)
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun isExerciseSafe(exerciseId: Int): Boolean {
        // Simple binary validation: coincidence between UserRestrictions and ExerciseRestrictions
        val exerciseRestrictions = try {
            apiService.getExerciseRestrictions(exerciseId)
        } catch (e: Exception) {
            emptyList<ExerciseRestrictions>()
        }
        
        val userRestrictionIds = _userRestrictions.value.map { it.restriction_id }.toSet()
        return exerciseRestrictions.none { it.restriction_id in userRestrictionIds }
    }

    companion object {
        fun create(baseUrl: String): WorkoutRepository {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logging)
                .build()

            val json = Json { ignoreUnknownKeys = true }
            val retrofit = Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
                .build()

            return WorkoutRepository(retrofit.create(ApiService::class.java))
        }
    }
}
