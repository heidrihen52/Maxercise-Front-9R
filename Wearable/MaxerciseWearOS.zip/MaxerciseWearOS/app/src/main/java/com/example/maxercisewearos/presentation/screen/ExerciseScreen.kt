package com.example.maxercisewearos.presentation.screen

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.wear.compose.material3.*
import com.example.maxercisewearos.presentation.viewmodel.WorkoutViewModel

@Composable
fun ExerciseScreen(
    viewModel: WorkoutViewModel,
    onStartRest: () -> Unit,
    onFinishWorkout: () -> Unit
) {
    val exercise by viewModel.currentExercise.collectAsStateWithLifecycle()
    val series by viewModel.currentSeries.collectAsStateWithLifecycle()
    val isSafe by viewModel.isSafe.collectAsStateWithLifecycle()
    
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(Unit) {
        viewModel.vibrationEvent.collect {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    ScreenScaffold {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = exercise?.exercise?.name ?: "Ejercicio",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = "Serie $series de ${exercise?.sets ?: 0} — ${exercise?.reps ?: 0} Reps",
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                val statusText = if (isSafe) "🟢 Seguro" else "🚫 No Seguro"
                val statusColor = if (isSafe) Color.Green else Color.Red
                Text(
                    text = statusText,
                    color = statusColor,
                    fontWeight = FontWeight.Bold
                )
            }

            if (!isSafe) {
                Text(
                    text = "No recomendado por tu condición médica.",
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                    color = Color.Red
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = { viewModel.completeSeries() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("✓")
                }
                
                Button(
                    onClick = onStartRest,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("⏱️")
                }
            }
        }
    }
}
