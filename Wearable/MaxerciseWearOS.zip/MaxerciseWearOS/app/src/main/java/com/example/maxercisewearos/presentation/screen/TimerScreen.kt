package com.example.maxercisewearos.presentation.screen

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.wear.compose.material3.*
import com.example.maxercisewearos.presentation.viewmodel.TimerViewModel

@Composable
fun TimerScreen(
    viewModel: TimerViewModel,
    onFinish: () -> Unit
) {
    val timeLeft by viewModel.timeLeft.collectAsStateWithLifecycle()
    val isRunning by viewModel.isRunning.collectAsStateWithLifecycle()
    
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(timeLeft, isRunning) {
        if (timeLeft == 0L && !isRunning) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            // Wait a bit before auto-closing if desired, or let user close
        }
    }

    ScreenScaffold {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = formatTime(timeLeft),
                style = MaterialTheme.typography.displayMedium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = { viewModel.adjustTime(-15) }) { Text("-15s") }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { viewModel.adjustTime(15) }) { Text("+15s") }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                if (isRunning) {
                    Button(onClick = { viewModel.pauseTimer() }) { Text("⏸️") }
                } else {
                    Button(onClick = { viewModel.resumeTimer() }) { Text("▶️") }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { 
                    viewModel.stopTimer()
                    onFinish()
                }) { Text("⏹️") }
            }
        }
    }
}

private fun formatTime(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%02d:%02d".format(m, s)
}
